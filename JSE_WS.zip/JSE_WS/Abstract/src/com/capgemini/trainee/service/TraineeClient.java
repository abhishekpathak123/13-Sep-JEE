/**
 * 
 */
package com.capgemini.trainee.service;

/**
 * @author apathak8
 *
 */
public class TraineeClient {

	private static ITraineeService traineeservice;
	private static Scanner sc;
	static{
		s c=new Scanner(System.in);
		traineeService = new TraineeServiceImp1(); 
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
        Trainee trainee = new Trainee(); 
		Trainee trainee = new Trainee[5];
         
	}

}
