/**
 * 
 */
package com.capgemini.trainee.service;

/**
 * @author apathak8
 *
 */
public class ITraineeService {

}
