package com.cg.eis.service;

import com.cg.eis.bean.Employee;

public interface IEmployeeService {
	int addEmployeeDetails();
	String findInsurenceScheme(double salary);
	Employee searchEmployee(int id);

}
