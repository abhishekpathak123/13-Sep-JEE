package com.cg.eis.pl;

import java.util.Scanner;

import com.cg.eis.service.IEmployeeService;

public class EmployeeClient {
	static IEmployeeService employeeService=new EmployeeServiceImpl();
	static Scanner sc=new Scanner (System.in);
	public static void main(String[] args){
		
	}

}
