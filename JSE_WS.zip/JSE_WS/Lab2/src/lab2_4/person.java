/**
 * 
 */
package lab2_4;

/**
 * @author apathak8
 *
 */
public class person {
	String firstName;
	String lastName;
	char gender;
	long PhoneNO;
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public char getGender() {
		return gender;
	}
	public void setGender(char gender) {
		this.gender = gender;
	}
	public long getPhoneNO() {
		return PhoneNO;
	}
	public void setPhoneNO(long phoneNO) {
		PhoneNO = phoneNO;
	}
	public person(String firstName, String lastName, char gender, long phoneNO) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.gender = gender;
		PhoneNO = phoneNO;
	}
	public person(){
		
	}}
    
		
	
	