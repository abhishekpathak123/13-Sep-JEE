package lab2_4;

import java.util.Scanner;

public class PersonMain2 {
    static person p2=new person();
    static Scanner sc = new Scanner(System.in);
    public static void main(String[] args){
    	addDetails();
    	displayDetails();
    	
    }
    private static void addDetails() {
    	System.out.println("Enter First Name:");
    	p2.setFirstName(sc.next());
    	System.out.println("Enter Last Name");
    	p2.setLastName(sc.next());
    	System.out.println("Enter Gender Name");
    	p2.setGender(sc.next().charAt(0));
    	System.out.println("ENter Phone no:");
    	p2.setPhoneNO(sc.nextLong());
    	
		
	}
    public static void displayDetails(){
    	System.out.println("\n__________________________________________"
		          + "\n         Person details                 "
		          + "\n__________________________________________"
		          + "\n       First Name          :"+p2.firstName
		          + "\n       Last Name           :"+p2.lastName 
		          + "\n       Gender              :"+p2.gender
		          + "\n       PhoneNo             :"+p2.PhoneNO
		          + "\n__________________________________________"
		          );
	}
    }

