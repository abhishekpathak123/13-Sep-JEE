package lab2_2;


/**
 * @author apathak8
 *
 */
public class InputUser {
//static final float PI=3.14f;
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		int a=Integer.parseInt(args[0]);
		if(a>0)
			System.out.println("Given no is Positive");
		else if(a<0)
			System.out.println("Given no is negative");
		else
			System.out.println("0 is neither positive nor Negative");
		
		
	}

}
