/**
 * 
 */
package com.capgemini.lab2_1;

/**
 * @author apathak8
 *
 */
public class EmployeeDetails {
	public static void main(String[] args) {
		
	
	String firstName="ABhishek";
	String lastName="Pathak";
	String gender="Male";
	float weight=22.98F;
	int age=66;
	System.out.println("\n__________________________________________"
	          + "\n         Person Details:                 "
	          + "\n__________________________________________"
	          + "\n       First Name          :"+firstName
	          + "\n       Last Name           :"+lastName
	          + "\n       Gender              :"+gender
	          + "\n       age                 :"+age
	          + "\n       weight              :"+weight
	          + "\n__________________________________________"
	          );
}
}