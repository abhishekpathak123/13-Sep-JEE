/**
 * 
 */
package lab2_3;

/**
 * @author apathak8
 *
 */
public class PersonMain {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
          person p1=new person("Divya","Bharti",'F');
          System.out.println("\n__________________________________________"
 		          + "\n         Person details                 "
 		          + "\n__________________________________________"
 		          + "\n       First Name          :"+p1.firstName
 		          + "\n       Last Name           :"+p1.lastName 
 		          + "\n       Gender              :"+p1.gender
 		          + "\n__________________________________________"
 		          );
	}

}
