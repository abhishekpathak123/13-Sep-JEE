/**
 * 
 */
package com.cpegemini.trainee;

import com.capgemini.date.MyDate;

/**
 * @author apathak8
 *
 */
public class JavaTrainee extends trainee{
    private String project;
    private String tools;
    public  JavaTrainee() {
		System.out.println("No-Arg JavaTrainee contr");
	}
		//getters and setters
	public JavaTrainee(String firstName, String lastName, long phoneNo,
			String email, MyDate dob, String project, String tools) {
		super(firstName, lastName, phoneNo, email, dob);
		this.project = project;
		this.tools = tools;
	}
	@Override
	public void print() {
		// TODO Auto-generated method stub
		super.print();
	}
	public String getProject() {
		return project;
	}
	public void setProject(String project) {
		this.project = project;
	}
	public String getTools() {
		return tools;
	}
	public void setTools(String tools) {
		this.tools = tools;
	}
	
}
