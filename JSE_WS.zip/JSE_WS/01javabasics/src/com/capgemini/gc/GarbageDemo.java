/**
 * 
 */
package com.capgemini.gc;

import com.capgemini.date.MyDate;

/**
 * @author apathak8
 *
 */
public class GarbageDemo {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
        MyDate dob = new MyDate();
        dob=null;
        System.gc();//requesting garbage collector
        
	}

}
