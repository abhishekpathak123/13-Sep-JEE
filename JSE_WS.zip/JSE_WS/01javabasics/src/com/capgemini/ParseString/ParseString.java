/**
 * 
 */
package com.capgemini.ParseString;

import java.util.Scanner;

/**
 * @author apathak8
 *
 */
public class ParseString {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		String str = "1,2,3,4,5,6,7,8";
		Scanner scanner = new Scanner(str).useDelimiter(",");
		while(scanner.hasNextInt()){
			int num = scanner.nextInt();
			if(num % 2 == 0){
				
					System.out.println(num);
					
				}
			}
		}

	}


