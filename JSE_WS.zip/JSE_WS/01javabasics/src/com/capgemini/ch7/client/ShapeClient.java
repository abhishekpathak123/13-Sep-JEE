/**
 * 
 */
package com.capgemini.ch7.client;

import com.capgemini.ch7.shape.Shape;
import com.capgemini.shape.circle.Circle;

/**
 * @author apathak8
 *
 */
public class ShapeClient {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Shape shape =new Circle(10.0f);
		shape.print()
		// TODO Auto-generated method stub

	}

}
