package com.capgemini.ch7.client;

public interface IPrintable {
	int MAX_COPIES=100;

	void print();
}
