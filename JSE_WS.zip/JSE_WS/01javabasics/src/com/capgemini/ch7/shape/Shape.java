/**
 * 
 */
package com.capgemini.ch7.shape;

/**
 * @author apathak8
 *
 */
public abstract class Shape {

	/**
	 * @param args
	
	 */
	protected abstract void draw();
	
	protected abstract void area();
	
	protected abstract void peripheri();
	
	protected void print(){
		System.out.println("Abstract Class ");
	}
}
