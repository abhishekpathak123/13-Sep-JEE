/**
 * 
 */
package com.capgemini.shape.circle;

import com.capgemini.ch7.shape.Shape;

/**
 * @author apathak8
 *
 */
public class Circle extends Shape {
	private static final float PI;
	private float radius ;
	static {
		PI=3.14f;
	}
	public float getRadius() {
		return radius;
	}
	public void setRadius(float radius) {
		this.radius = radius;
	}
	public static float getPi() {
		return PI;
	}
	@Override
	protected void draw() {
		// TODO Auto-generated method stub
		System.out.println("Drawing circle....");
	}
	@Override
	protected void area() {
		// TODO Auto-generated method stub
		System.out.println("Area of circle is    :"+(PI*radius*radius));
		
	}
	@Override
	protected void peripheri() {
		// TODO Auto-generated method stub
		System.out.println("Circumfrence of a circle is   :"+(2*PI*radius));
	}

}
