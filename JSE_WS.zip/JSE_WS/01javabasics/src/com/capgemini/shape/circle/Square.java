package com.capgemini.shape.circle;

public class Square extends Shape {
	private float sides;
	public  () {
		
	}

}
